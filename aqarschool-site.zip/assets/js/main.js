/* ==========================================================================
   AQAR SCHOOL - Main JavaScript
   ========================================================================== */

/* ---------- Beta Banner (injected on every page) ---------- */
(function injectBetaBanner(){
  // Only inject once; skip if a banner already exists
  if (document.querySelector('.beta-banner') || document.querySelector('.demo-banner')) return;

  function insert() {
    if (!document.body) return;
    var path = (location.pathname || '').toLowerCase();
    var isDashboard = /\/dashboards\//.test(path);
    var lang = (document.documentElement.getAttribute('lang') || 'ar').toLowerCase();
    var banner = document.createElement('div');

    if (isDashboard) {
      banner.className = 'demo-banner';
      banner.innerHTML = lang.startsWith('en')
        ? '<span class="demo-chip">Demo</span> <span>⚠️ This is a sample dashboard with example data — not a real account.</span>'
        : '<span class="demo-chip">عرض توضيحي</span> <span>⚠️ دي شاشة تجريبية بأرقام للتوضيح — مش حساب حقيقي.</span>';
    } else {
      banner.className = 'beta-banner';
      banner.innerHTML = lang.startsWith('en')
        ? '<span class="beta-chip">Beta</span> <span>🚀 We just launched! <b>aqarschool.com</b> is in beta — features and content are evolving daily.</span>'
        : '<span class="beta-chip">نسخة بيتا</span> <span>🚀 الموقع لسه في بدايته — <b>aqarschool.com</b> نسخة بيتا، الميزات والمحتوى بيتطوّروا يومياً.</span>';
    }
    document.body.insertBefore(banner, document.body.firstChild);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', insert);
  } else {
    insert();
  }
})();

/* ---------- Mobile Nav ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => links.classList.toggle("open"));
  }
});

/* ---------- Number Formatting ---------- */
function formatNumber(n, lang) {
  lang = lang || document.documentElement.getAttribute("lang") || "ar";
  const locale = lang === "ar" ? "ar-EG" : "en-US";
  return new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(n);
}

/* ---------- Animated Counters ---------- */
function animateCounter(el, target, duration = 1600) {
  const start = 0;
  const startTime = performance.now();
  function tick(now) {
    const t = Math.min((now - startTime) / duration, 1);
    const eased = 1 - Math.pow(1 - t, 3);
    el.textContent = formatNumber(Math.round(start + (target - start) * eased));
    if (t < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}
document.addEventListener("DOMContentLoaded", () => {
  const counters = document.querySelectorAll("[data-counter]");
  const obs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        const el = e.target;
        animateCounter(el, parseInt(el.getAttribute("data-counter"), 10));
        obs.unobserve(el);
      }
    });
  });
  counters.forEach(c => obs.observe(c));
});

/* ---------- Multi-Step Form ---------- */
function initStepper(formId) {
  const form = document.getElementById(formId);
  if (!form) return;
  const steps = form.querySelectorAll(".form-step");
  const indicators = form.querySelectorAll(".step");
  let current = 0;

  function show(i) {
    current = i;
    steps.forEach((s, idx) => s.classList.toggle("active", idx === i));
    indicators.forEach((s, idx) => {
      s.classList.toggle("active", idx === i);
      s.classList.toggle("completed", idx < i);
    });
    window.scrollTo({ top: form.offsetTop - 100, behavior: "smooth" });
  }

  form.querySelectorAll("[data-next]").forEach(btn => {
    btn.addEventListener("click", () => {
      if (current < steps.length - 1) show(current + 1);
    });
  });
  form.querySelectorAll("[data-back]").forEach(btn => {
    btn.addEventListener("click", () => {
      if (current > 0) show(current - 1);
    });
  });

  show(0);
}

/* ---------- Signature Pad ---------- */
function initSignature(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  function resize() {
    const ratio = window.devicePixelRatio || 1;
    const w = canvas.offsetWidth;
    const h = canvas.offsetHeight;
    canvas.width = w * ratio;
    canvas.height = h * ratio;
    ctx.scale(ratio, ratio);
    ctx.strokeStyle = "#1E40AF";
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
  }
  resize();
  window.addEventListener("resize", resize);

  let drawing = false;
  let last = null;

  function pos(e) {
    const rect = canvas.getBoundingClientRect();
    const t = e.touches ? e.touches[0] : e;
    return { x: t.clientX - rect.left, y: t.clientY - rect.top };
  }

  function start(e) { e.preventDefault(); drawing = true; last = pos(e); }
  function move(e) {
    if (!drawing) return; e.preventDefault();
    const p = pos(e);
    ctx.beginPath();
    ctx.moveTo(last.x, last.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last = p;
  }
  function end() { drawing = false; }

  canvas.addEventListener("mousedown", start);
  canvas.addEventListener("mousemove", move);
  canvas.addEventListener("mouseup", end);
  canvas.addEventListener("mouseleave", end);
  canvas.addEventListener("touchstart", start);
  canvas.addEventListener("touchmove", move);
  canvas.addEventListener("touchend", end);

  const clearBtn = document.querySelector(`[data-sig-clear="${canvasId}"]`);
  if (clearBtn) clearBtn.addEventListener("click", () => {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  });
}

/* ---------- Modal ---------- */
function openModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.add("open");
}
function closeModal(id) {
  const m = document.getElementById(id);
  if (m) m.classList.remove("open");
}
document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-modal-open]").forEach(b => {
    b.addEventListener("click", () => openModal(b.getAttribute("data-modal-open")));
  });
  document.querySelectorAll("[data-modal-close]").forEach(b => {
    b.addEventListener("click", () => closeModal(b.getAttribute("data-modal-close")));
  });
  document.querySelectorAll(".modal-backdrop").forEach(b => {
    b.addEventListener("click", e => { if (e.target === b) b.classList.remove("open"); });
  });
});

/* ---------- Mortgage Calculator ---------- */
function initMortgage() {
  const price = document.getElementById("m-price");
  const down = document.getElementById("m-down");
  const years = document.getElementById("m-years");
  const rate = document.getElementById("m-rate");
  if (!price || !down || !years || !rate) return;

  const priceOut = document.getElementById("m-price-out");
  const downOut = document.getElementById("m-down-out");
  const yearsOut = document.getElementById("m-years-out");
  const rateOut = document.getElementById("m-rate-out");

  const monthly = document.getElementById("m-monthly");
  const total = document.getElementById("m-total");
  const interest = document.getElementById("m-interest");
  const loanOut = document.getElementById("m-loan");

  function calc() {
    const P = +price.value;
    const D = +down.value;
    const Y = +years.value;
    const R = +rate.value;

    const loan = Math.max(P - D, 0);
    const r = (R / 100) / 12;
    const n = Y * 12;
    let mo = 0;
    if (r > 0 && n > 0) {
      mo = loan * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
    } else if (n > 0) {
      mo = loan / n;
    }
    const tot = mo * n;
    const intr = tot - loan;

    priceOut.textContent = formatNumber(P);
    downOut.textContent = formatNumber(D);
    yearsOut.textContent = Y;
    rateOut.textContent = R.toFixed(2);

    monthly.textContent = formatNumber(Math.round(mo));
    total.textContent = formatNumber(Math.round(tot));
    interest.textContent = formatNumber(Math.round(intr));
    loanOut.textContent = formatNumber(Math.round(loan));
  }

  [price, down, years, rate].forEach(i => i.addEventListener("input", calc));
  calc();
}
document.addEventListener("DOMContentLoaded", initMortgage);

/* ---------- Dashboard Sidebar Toggle ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const dashToggle = document.querySelector("[data-dash-toggle]");
  const sidebar = document.querySelector(".dash-sidebar");
  if (dashToggle && sidebar) {
    dashToggle.addEventListener("click", () => sidebar.classList.toggle("open"));
  }
});

/* ---------- AI Widget Demo ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const ai = document.querySelector(".ai-helper");
  if (ai) ai.addEventListener("click", () => {
    const lang = (typeof getLang === "function") ? getLang() : (document.documentElement.lang || "ar");
    const dict = (typeof translations !== "undefined" && translations[lang]) ? translations[lang] : null;
    const msg = (dict && dict["ai.greeting"])
      ? dict["ai.greeting"]
      : (lang === "ar"
          ? "مرحباً! أنا مساعد عقار سكول الذكي. كيف أقدر أساعدك في إيجاد وحدتك المثالية؟"
          : "Hi! I'm the Aqar School AI Assistant. How can I help you find your perfect unit?");
    alert(msg);
  });
});

/* ---------- Back-to-Top Button ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("backToTop");
  if (!btn) return;
  window.addEventListener("scroll", () => {
    if (window.scrollY > 400) btn.classList.add("show");
    else btn.classList.remove("show");
  }, { passive: true });
  btn.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
});

/* ---------- Mobile Nav Toggle ---------- */
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.querySelector(".nav-toggle");
  const links = document.querySelector(".nav-links");
  if (toggle && links) {
    toggle.addEventListener("click", () => links.classList.toggle("open"));
  }
});
