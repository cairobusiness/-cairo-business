/* ==========================================================================
   AQAR SCHOOL — Supabase Client
   Loaded on pages that need to write to the database (submit, contact, signup)
   ========================================================================== */
(function(){
  var SUPABASE_URL = 'https://hgvahzihhyvnsboxufkc.supabase.co';
  var SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImhndmFoemloaHl2bnNib3h1ZmtjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzkzMTYxNDcsImV4cCI6MjA5NDg5MjE0N30.uvvkZ0K5-DJege1u2mZ5fyjIOUcE4RJW0i9vA6Fss2Q';

  function loadSdk(cb){
    if (window.supabase) return cb();
    var s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
    s.onload = function(){ cb(); };
    s.onerror = function(){ console.warn('Failed to load Supabase SDK'); cb(); };
    document.head.appendChild(s);
  }

  loadSdk(function(){
    if (!window.supabase) return;
    window.aqSb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

    // Public helper: insert a property submission
    window.aqSubmitProperty = function(sfData){
      if (!window.aqSb) return Promise.reject(new Error('Supabase not loaded'));
      var row = {
        submitter_name: sfData && (sfData.contact && sfData.contact.name) || sfData.name || null,
        submitter_email: sfData && (sfData.contact && sfData.contact.email) || sfData.email || null,
        submitter_phone: sfData && (sfData.contact && sfData.contact.phone) || sfData.phone || null,
        intent: sfData && (sfData.s1State && sfData.s1State.intent) || sfData.intent || null,
        property_type: sfData && (sfData.s1State && sfData.s1State.type) || sfData.type || null,
        condition: sfData && (sfData.s1State && sfData.s1State.condition) || sfData.condition || null,
        title: sfData && (sfData.title || sfData.unitName) || null,
        description: sfData && (sfData.description || sfData.notes) || null,
        city: sfData && (sfData.city || sfData.location) || null,
        area: sfData && (sfData.area || sfData.compound) || null,
        bedrooms: sfData && Number(sfData.bedrooms) || null,
        bathrooms: sfData && Number(sfData.bathrooms) || null,
        size_m2: sfData && Number(sfData.size || sfData.area_m2) || null,
        price: sfData && Number(sfData.price) || null,
        currency: 'EGP',
        status: 'pending',
        raw_data: sfData
      };
      return window.aqSb.from('aqarschool_properties').insert([row]).select();
    };

    // Public helper: insert a contact message
    window.aqSubmitContact = function(payload){
      if (!window.aqSb) return Promise.reject(new Error('Supabase not loaded'));
      var row = {
        topic: payload.topic || 'general',
        name: payload.name || null,
        email: payload.email || null,
        phone: payload.phone || null,
        subject: payload.subject || null,
        message: payload.message || null,
        status: 'new'
      };
      return window.aqSb.from('aqarschool_contacts').insert([row]).select();
    };

    // Public helper: insert a user signup (broker / developer / client)
    window.aqSubmitUser = function(payload){
      if (!window.aqSb) return Promise.reject(new Error('Supabase not loaded'));
      var row = {
        full_name: payload.full_name || payload.name || null,
        email: payload.email || null,
        phone: payload.phone || null,
        role: payload.role || 'client',
        company: payload.company || null,
        city: payload.city || null,
        bio: payload.bio || null,
        status: 'pending',
        raw_data: payload
      };
      return window.aqSb.from('aqarschool_users').insert([row]).select();
    };

    // Public helper: fetch approved properties (for listings.html, etc.)
    window.aqFetchApprovedProperties = function(limit){
      if (!window.aqSb) return Promise.reject(new Error('Supabase not loaded'));
      return window.aqSb
        .from('aqarschool_properties')
        .select('*')
        .in('status', ['approved','published'])
        .order('created_at', { ascending: false })
        .limit(limit || 24);
    };

    // Public helper: fetch published news
    window.aqFetchPublishedNews = function(limit){
      if (!window.aqSb) return Promise.reject(new Error('Supabase not loaded'));
      return window.aqSb
        .from('aqarschool_news')
        .select('*')
        .eq('status', 'published')
        .order('published_at', { ascending: false })
        .limit(limit || 12);
    };
  });
})();
