/* ==============================================================
   AQAR SCHOOL — Extended Phrase Translations
   ==============================================================
   Catches full Arabic phrases used in newer pages
   (submit / price-check / broker-arena / launches / business-deals)
   and translates them to English when language toggles.

   Hooks: listens to html.dir/lang mutations + initial load
   Strategy: text-node exact match (preserves whitespace)
   ============================================================== */

(function () {
  'use strict';

  /* =======================================================
     PHRASE DICTIONARY — full sentences, headlines, labels
     ======================================================= */
  const PHRASES = {

    // ===== HOMEPAGE — New Zillow-style tool cards =====
    "سجل الصفقات": "Recently Sold",
    "آخر ١٠٠ صفقة موثّقة": "Last 100 verified deals",
    "Open Houses": "Open Houses",
    "معاينات هذا الأسبوع": "This week's viewings",
    "تنبيهات ذكية": "Smart Alerts",
    "SMS فور نزول وحدة": "SMS the moment a unit lists",
    "BuyAbility": "BuyAbility",
    "كم تقدر تشتري؟": "How much can you afford?",
    "إيجار vs شراء": "Rent vs Buy",
    "احسب نقطة التعادل": "Calculate the break-even",
    "مقارنة العقارات": "Compare Properties",
    "٣ وحدات side-by-side": "3 units side-by-side",
    "AqarValue": "AqarValue",
    "قيمة وحدتك بـ AI": "Your AI-powered home value",
    "Coming Soon": "Coming Soon",
    "قبل ٧ أيام من النشر": "7 days before public release",
    "إدارة الإيجارات": "Rentals Manager",
    "٤ أدوات للمالك": "4 landlord tools",
    "فحص المستأجر": "Renter Screening",
    "Trust Score بالـ AI": "AI Trust Score",
    "عقد إيجار رقمي": "Digital Lease",
    "Blockchain موثّق": "Blockchain-verified",

    // ===== HOMEPAGE — Quick booking form (personal advisor) =====
    "هل تواصلت مع مستشار من قبل؟": "Have you contacted an advisor before?",
    "متابعة شخصية": "Personal follow-up",
    "لو تم تعريفك بالوحدة عن طريق مستشار عقاري معيّن، اكتب اسمه واسم الشركة — علشان نضمنلك متابعة احترافية متكاملة من نفس الشخص اللي ساعدك من البداية لحد إتمام الحجز.":
      "If you were introduced to the unit via a specific real-estate advisor, write their name and company — so we can guarantee end-to-end follow-up from the same person who helped you from start to booking.",
    "✓ تجربة موحّدة. مستشار واحد. ثقة كاملة.":
      "✓ Unified experience. One advisor. Full trust.",
    "تجربة موحّدة. مستشار واحد. ثقة كاملة.":
      "Unified experience. One advisor. Full trust.",
    "اسم المستشار العقاري": "Real-estate advisor name",
    "الشركة العقارية": "Real-estate company",
    "— لم أتواصل مع شركة —": "— Haven't contacted a company —",
    "لم أتواصل مع شركة": "Haven't contacted a company",
    "الرقم التعريفي (لو متوفر) #": "Reference number (if available) #",
    "الرقم التعريفي": "Reference number",
    "(لو متوفر)": "(if available)",
    "رقم المستشار (اختياري — لتسهيل التواصل)":
      "Advisor number (optional — for easier contact)",
    "رقم المستشار": "Advisor number",
    "(اختياري — لتسهيل التواصل)": "(optional — for easier contact)",
    "مثلاً: أحمد مصطفى": "e.g. Ahmed Mostafa",
    "مثلاً: AS-1234": "e.g. AS-1234",

    // ===== HOMEPAGE — InstaPay panel =====
    "تحويل فوري": "Instant transfer",
    "InstaPay — تحويل فوري": "InstaPay — Instant transfer",
    "آمن · مجاناً · 0 رسوم · 24/7": "Safe · Free · 0 fees · 24/7",
    "آمن": "Safe",
    "مجاناً": "Free",
    "0 رسوم": "0 fees",
    "البنك / المحفظة": "Bank / Wallet",
    "عنوان InstaPay (IPA)": "InstaPay address (IPA)",
    "— اختر البنك —": "— Choose a bank —",
    "اختر البنك": "Choose a bank",
    "مثلاً: ahmed@cib أو@nbe 01012345678": "e.g. ahmed@cib or @nbe 01012345678",
    "رقم الموبايل المرتبط بحساب InstaPay": "Mobile linked to your InstaPay account",
    "رقم الموبايل المرتبط بحساب": "Mobile linked to account",
    "سيتم تحويل المبلغ إلى:": "Amount will be transferred to:",
    "سيتم تحويل المبلغ إلى": "Amount will be transferred to",
    "عقار سكول للضمانات": "Aqar School Escrow",
    "نسخ": "Copy",

    // ===== Quick booking — broader =====
    "حجز سريع": "Quick booking",
    "بيانات الحجز": "Booking details",
    "احجز معاينة": "Book a viewing",
    "احجز الآن": "Book now",
    "الاسم بالكامل": "Full name",
    "رقم الموبايل": "Mobile number",
    "البريد الإلكتروني": "Email",
    "تأكيد الحجز": "Confirm booking",
    "اضغط لتأكيد الحجز": "Click to confirm booking",
    "طريقة الدفع": "Payment method",
    "اختر طريقة الدفع": "Choose payment method",
    "كاش": "Cash",
    "تحويل بنكي": "Bank transfer",
    "بطاقة ائتمان": "Credit card",
    "محفظة إلكترونية": "E-wallet",
    "Fawry": "Fawry",
    "InstaPay": "InstaPay",
    "PayMob": "PayMob",
    "Vodafone Cash": "Vodafone Cash",

    // ===== Footer organized — fix small leftovers =====
    "AI بحث": "AI Search",
    "بحث AI Plus": "AI Search Plus",
    "AI أدوات": "AI tools",
    "VIP صفقات": "VIP deals",
    "💼 الوظائف": "💼 Jobs",
    "💎 صفقات VIP": "💎 VIP Deals",
    "💼 صفقات VIP": "💼 VIP Deals",
    "🚀 إطلاقات المشاريع": "🚀 Project Launches",
    "🏆 عقار أرينا": "🏆 Aqar Arena",
    "🎓 أكاديمية المبيعات": "🎓 Sales Academy",
    "🛠️ خدمات ما بعد الشراء": "🛠️ Post-Purchase Services",
    "🤖 أدوات AI الجديدة": "🤖 New AI Tools",
    "🤖 أدوات AI": "🤖 AI Tools",
    "🔨 مزادات لحظية": "🔨 Live Auctions",
    "📸 ستوريز السماسرة": "📸 Broker Stories",
    "🪄 بحث AI": "🪄 AI Search",
    "أكاديمية المبيعات": "Sales Academy",
    "بروفايل سمسار": "Broker profile",
    "لوحة السمسار": "Broker dashboard",
    "لوحة المطوّر": "Developer dashboard",
    "لوحة العميل": "Client dashboard",
    "لوحة الإدارة": "Admin dashboard",
    "إطلاقات المشاريع": "Project launches",
    "صفقات VIP": "VIP deals",
    "إدارة العقار": "Property management",
    "جدار المجتمع": "Community wall",
    "توب 10": "Top 10",
    "البورصة العقارية": "Real-estate stocks",
    "حاسبة التمويل": "Mortgage calculator",
    "حجز أوف بلان": "Off-plan booking",
    "هل السعر عادل؟": "Is the price fair?",
    "مزادات لحظية": "Live auctions",
    "ستوريز السماسرة": "Broker stories",
    "خدمات ما بعد الشراء": "Post-purchase services",
    "أضِف عقارك": "List your property",
    "أضف عقارك": "List your property",
    "المميزات": "Features",
    "الأخبار": "News",
    "البودكاست": "Podcast",
    "الوظائف": "Jobs",
    "تواصل معنا": "Contact us",
    "تسجيل دخول": "Sign in",
    "أنشئ حساب جديد →": "Create new account →",
    "أنشئ حساب جديد": "Create new account",

    // ===== Footer columns labels =====
    "للمشترين": "For Buyers",
    "للبائعين": "For Sellers",
    "للسماسرة والمطورين": "For Brokers & Developers",
    "عن عقار سكول": "About Aqar School",

    // Hero quick-tools group labels
    "للمشترين والباحثين": "For Buyers & Searchers",
    "أدوات AI الذكية": "Smart AI Tools",
    "للبائعين والمُلّاك": "For Sellers & Owners",
    "للسماسرة والمطورين": "For Brokers & Developers",
    "اكتشف وتعلّم": "Discover & Learn",

    // ===== Newsletter =====
    "نشرة عقار سكول الأسبوعية": "Aqar School weekly newsletter",
    "أحدث الوحدات + تحليلات السوق": "Latest units + market analytics",
    "في إيميل أسبوعي.": "in a weekly email.",
    "في إيميل أسبوعي": "in a weekly email",
    "اشتراك مجاناً": "Subscribe free",
    "تم الاشتراك ✓": "Subscribed ✓",
    "40 ألف مشترك بيتلقّوا أهم الفرص قبل ما تطلع للناس. لو الإيميل ما عجبكش، تقدر تلغي بضغطة.":
      "40,000 subscribers get top opportunities before they hit the public. Don't like the email? Unsubscribe in one click.",
    "٤٠ ألف مشترك بيتلقّوا أهم الفرص قبل ما تطلع للناس. لو الإيميل ما عجبكش، تقدر تلغي بضغطة.":
      "40,000 subscribers get top opportunities before they hit the public. Don't like the email? Unsubscribe in one click.",
    "حمّل من": "Download on",

    // Quick tool taglines visible in screenshot
    "ألف وحدة متاحة 12": "12K units available",
    "١٢ ألف وحدة متاحة": "12K units available",
    "12 ألف وحدة متاحة": "12K units available",
    "خريطة أدوار حية": "Live floor map",
    "مزادات الآن 4": "4 auctions now",
    "٤ مزادات الآن": "4 auctions now",
    "4 مزادات الآن": "4 auctions now",
    "آخر الوحدات قبل النشر": "Latest units pre-launch",
    "وحدات للاستلام الفوري": "Move-in-ready units",
    "جاهزة للسكن": "Ready to live in",

    // ===== HOMEPAGE — Stories rail =====
    "ستوريز السماسرة والمطورين": "Broker & Developer Stories",
    "٢٤ ساعة فقط": "24 hours only",
    "انشر ستوري": "Post a story",
    "إنت": "You",
    "سمسار": "Broker",
    "مطوّر": "Developer",
    "شركة تسويق": "Marketing agency",
    "سارة م.": "Sara M.",
    "أحمد ك.": "Ahmed K.",
    "كريم ن.": "Karim N.",
    "إعمار مصر": "Emaar Misr",
    "TMG": "TMG",
    "مارينا للتسويق": "Marina Marketing",
    "نورهان س.": "Nourhan S.",
    "هايد بارك": "Hyde Park",
    "رانيا ع.": "Rania A.",
    "العاصمة برو": "Capital Pro",
    "سوديك": "SODIC",
    "منذ ساعة": "1h ago",
    "منذ ٢ ساعة": "2h ago",
    "منذ ٣ ساعات": "3h ago",
    "منذ ٤ ساعات": "4h ago",
    "منذ ٥ ساعات": "5h ago",
    "منذ ٦ ساعات": "6h ago",
    "منذ ٧ ساعات": "7h ago",
    "منذ ٨ ساعات": "8h ago",
    "منذ ١٠ ساعات": "10h ago",
    "منذ ١٢ ساعة": "12h ago",
    "منذ ٣٠ دقيقة": "30 min ago",
    "منذ ساعتين": "2h ago",
    "منذ ١ س": "1h",
    "منذ ٢ س": "2h",
    "منذ ٣ س": "3h",
    "منذ ٤ س": "4h",
    "منذ ٥ س": "5h",
    "منذ ٦ س": "6h",
    "منذ ٧ س": "7h",
    "كلّم البائع": "Call seller",
    "احفظ": "Save",
    "شقة فاضية · مدينتي B11": "Empty apt · Madinaty B11",
    "مدينتي · القاهرة الجديدة": "Madinaty · New Cairo",
    "إطلاق جديد · سوديك ايست": "New launch · SODIC East",
    "القاهرة الجديدة": "New Cairo",
    "فيلا بيفرلي هيلز": "Beverly Hills villa",
    "زايد": "Sheikh Zayed",
    "ميفيدا · فرصة استثمارية": "Mivida · investment opportunity",
    "نون · مدينتي": "Noon · Madinaty",
    "مدينتي": "Madinaty",
    "٢٠ وحدة في كمبوند واحد": "20 units in one compound",
    "العاصمة الإدارية": "New Capital",
    "شاليه أزها": "Azha chalet",
    "العين السخنة": "Ain Sokhna",
    "فيو حديقة · هايد بارك": "Garden view · Hyde Park",
    "٣.٨ مليون": "3.8M",
    "٤.٥ مليون": "4.5M",
    "من ٤.٥ مليون": "From 4.5M",
    "١٨ مليون": "18M",
    "٦.٢ مليون": "6.2M",
    "من ٣.٢ مليون": "From 3.2M",
    "من ٢.٢ مليون": "From 2.2M",
    "٤.٢ مليون": "4.2M",
    "٦.٥ مليون": "6.5M",
    "٣.٢ مليون": "3.2M",
    "٢.٨ مليون": "2.8M",
    "١٢ مليون": "12M",
    "١٥ مليون": "15M",

    // ===== HOMEPAGE — Videos section =====
    "فيديوهات السوق": "Market Videos",
    "آخر الفيديوهات من شركات التطوير والسماسرة على إنستجرام وفيسبوك.":
      "The latest videos from developers and brokers on Instagram and Facebook.",
    "الكل": "All",
    "مطورون": "Developers",
    "سماسرة": "Brokers",
    "شركات تسويق": "Agencies",
    "فيديو embed من إنستجرام / فيسبوك": "Video embed from Instagram / Facebook",
    "تواصل": "Contact",
    "افتح الأصلي": "Open original",
    "جولة في فيلا سوديك ايست — ٤ غرف وحديقة خاصة":
      "Tour of SODIC East villa — 4 BR and private garden",
    "سوديك للتطوير العقاري": "SODIC for Real Estate Development",
    "شقة طابق أرضي بفيو حديقة — مدينتي B7":
      "Ground-floor apt with garden view — Madinaty B7",
    "كريم نبيل": "Karim Nabil",
    "إطلاق نون — مرحلة جديدة من مدينتي ٢٠٢٦":
      "Noon launch — new Madinaty phase 2026",
    "مجموعة طلعت مصطفى": "Talaat Moustafa Group",
    "٢٠ وحدة في كمبوند واحد · مزاد اليوم": "20 units in one compound · auction today",
    "فيلا في بيفرلي هيلز — جولة كاملة بالتفاصيل":
      "Beverly Hills villa — full detailed tour",
    "سارة محمود": "Sara Mahmoud",
    "هايد بارك · المرحلة الخامسة من البيع":
      "Hyde Park · 5th sales phase",
    "هايد بارك للتطوير": "Hyde Park Development",
    "شاليهات رأس الحكمة — عروض الصيف ٢٠٢٦":
      "Ras El Hekma chalets — summer 2026 offers",
    "تاون هاوس في ميفيدا — سعر ممتاز":
      "Townhouse in Mivida — excellent price",
    "نورهان السيد": "Nourhan El-Sayed",

    // ===== HOMEPAGE — News section =====
    "آخر أخبار السوق العقاري": "Latest Real-Estate Market News",
    "أخبار، تحليلات، ومستجدات السوق المصري — مع ملخص AI لكل خبر.":
      "News, analysis, and updates on the Egyptian market — with an AI summary for each story.",
    "كل الأخبار": "All news",
    "السوق": "Market",
    "المطورون": "Developers",
    "قانون وتمويل": "Law & finance",
    "إطلاقات": "Launches",
    "الساحل": "North Coast",
    "ابحث في الأخبار...": "Search news...",
    "عاجل": "BREAKING",
    "جديد": "NEW",
    "تنبيه": "ALERT",
    "إطلاق": "LAUNCH",
    "إيجابي": "Positive",
    "محايد": "Neutral",
    "سلبي": "Negative",
    "ملخص AI متاح": "AI summary available",
    "ملخص الذكاء الاصطناعي · ٣ نقاط": "AI summary · 3 points",
    "خبر": "Article",
    "استمع للخبر": "Listen to article",
    "شارك": "Share",
    "لم نجد خبر يطابق بحثك": "No articles matched your search",
    "عقار سكول · تحليلات": "Aqar School · Analytics",
    "عقار سكول": "Aqar School",
    "وزارة الإسكان": "Ministry of Housing",
    "تحليلات السوق": "Market analytics",
    "سوديك للتطوير": "SODIC Development",
    "البنك الأهلي": "National Bank of Egypt",
    "العاصمة الإدارية تشهد ارتفاع ٣٥٪ في صفقات الربع الأول من ٢٠٢٦":
      "New Capital sees 35% surge in Q1 2026 deals",
    "نمو غير مسبوق مدفوع بالبنية التحتية الجديدة وبرامج التمويل البنكي. مبيعات المرحلة R7 تجاوزت ٢٢ مليار جنيه.":
      "Unprecedented growth driven by new infrastructure and bank financing programs. R7 sales topped 22B EGP.",
    "إعمار تعلن إطلاق مرحلة جديدة في ميفيدا بـ ٥٠٠ وحدة":
      "Emaar announces new Mivida phase with 500 units",
    "الأسعار تبدأ من ٤.٢ مليون جنيه، وخطة سداد على ١٠ سنوات بدون فوائد.":
      "Prices start at 4.2M EGP, with 10-year interest-free payment plan.",
    "تعديل جديد في قانون الشهر العقاري — موعد التطبيق سبتمبر ٢٠٢٦":
      "New amendment to the property registration law — effective September 2026",
    "تقصير مدة التسجيل من ٦٠ يوم إلى ٢١ يوم، وتخفيض رسوم الشهر العقاري ٢٠٪.":
      "Registration period cut from 60 days to 21 days, and a 20% fee reduction.",
    "رأس الحكمة تشهد طفرة في حجوزات الصيف — ارتفاع ٤٢٪":
      "Ras El Hekma sees summer-bookings surge — up 42%",
    "٧ مطورين أعلنوا مشاريع جديدة، والأسعار قفزت ٢٥٪ مقارنة بـ ٢٠٢٥.":
      "7 developers announced new projects, and prices jumped 25% vs 2025.",
    "TMG تطلق مشروع 'نون' في مدينتي — ١٢٠٠ وحدة دفعة واحدة":
      "TMG launches 'Noon' in Madinaty — 1,200 units at once",
    "مشروع يستهدف العائلات الشابة، تشطيب سوبر لوكس، أسعار تنافسية.":
      "Project targets young families, super-lux finish, competitive pricing.",
    "تراجع طفيف في مبيعات الوحدات الفاخرة — لماذا؟":
      "Slight dip in luxury-unit sales — why?",
    "المشترون يفضلون وحدات المرحلة المتوسطة. تأثر سوق الفلل بقوة الدولار.":
      "Buyers favor mid-segment units. Villa market hit by dollar strength.",
    "سوديك تستهدف ٨ مليار مبيعات في ٢٠٢٦":
      "SODIC targets 8B EGP in sales for 2026",
    "خطة طموحة تتضمن ٤ مشاريع جديدة في القاهرة الجديدة والساحل الشمالي.":
      "Ambitious plan including 4 new projects in New Cairo and the North Coast.",
    "البنك الأهلي يطلق برنامج تمويل عقاري بفائدة ٧.٥٪":
      "NBE launches mortgage program at 7.5% interest",
    "أقل فائدة في السوق، فترة سداد تصل لـ ٢٥ سنة، حتى ٨٠٪ من قيمة العقار.":
      "Lowest rate in the market, terms up to 25 years, financing up to 80% of value.",

    // ===== HOMEPAGE — Quick tools group labels =====
    "للمشترين والباحثين": "For Buyers & Searchers",
    "أدوات AI الذكية": "Smart AI Tools",
    "للبائعين والمُلّاك": "For Sellers & Owners",
    "للسماسرة والمطورين": "For Brokers & Developers",
    "اكتشف وتعلّم": "Discover & Learn",
    "٢٣ أداة وقسم بتشتغل لك بالـ AI — كل واحدة منفصلة وفعّالة":
      "23 tools and sections powered by AI — each one focused and effective",

    // ===== HOMEPAGE — Quick tool tiles (new ones) =====
    "العقارات": "Properties",
    "١٢ ألف وحدة متاحة": "12K units available",
    "تحليل فوري بالـ XGBoost": "Instant XGBoost analysis",
    "قارن ١٥ بنك": "Compare 15 banks",
    "خريطة أدوار حية": "Live floor map",
    "مزادات لحظية": "Live auctions",
    "٤ مزادات الآن": "4 auctions now",
    "ستوريز السماسرة": "Broker stories",
    "آخر الوحدات قبل النشر": "Latest units pre-launch",
    "وحدات للاستلام الفوري": "Move-in-ready units",
    "جاهزة للسكن": "Ready to live in",
    "جولة AI ٣٦٠°": "AI 360° tour",
    "٥ صور → جولة كاملة": "5 photos → full tour",
    "فرشة الغرفة AI": "AI room staging",
    "٦ ستايلات أثاث": "6 furniture styles",
    "حاسبة التشطيب": "Finishing calculator",
    "أسعار السوق ٢٠٢٦": "2026 market prices",
    "البورصة العقارية": "Real-estate stocks",
    "٨ أسهم EGX حية": "8 live EGX stocks",
    "أضِف عقارك": "List your property",
    "معالج ٦ خطوات": "6-step wizard",
    "خدمات ما بعد الشراء": "Post-purchase services",
    "نقل · تنظيف · معاينة": "Moving · cleaning · inspection",
    "إدارة العقار": "Property management",
    "فرش / تشطيب / تأجير": "Furnish / finish / rent",
    "جدار المجتمع": "Community wall",
    "٤٨ ألف مستخدم نشط": "48K active users",
    "أكاديمية المبيعات": "Sales Academy",
    "٦ أسابيع تدريب": "6 weeks of training",
    "عقار أرينا": "Aqar Arena",
    "منافسة مع جوائز": "Competition with prizes",
    "السماسرة": "Brokers",
    "٢٤٠٠+ معتمد": "2,400+ verified",
    "توب 10": "Top 10",
    "ترتيب المطورين": "Developer rankings",
    "إطلاقات المشاريع": "Project launches",
    "تسكين أون لاين": "Live online booking",
    "صفقات VIP": "VIP deals",
    "أراضٍ للأعمال": "Business plots",
    "الوظائف": "Jobs",
    "١٢٥٠٠ متخصص": "12,500 specialists",
    "لوحات التحكم": "Dashboards",
    "سمسار · مطوّر · عميل": "Broker · developer · client",
    "الأخبار": "News",
    "أخبار السوق + AI": "Market news + AI",
    "البودكاست": "Podcast",
    "حلقات مع خبراء": "Episodes with experts",
    "المميزات": "Features",
    "٢٣ ميزة شاملة": "23 full features",
    "تواصل معنا": "Contact us",
    "دعم ٢٤/٧": "24/7 support",
    "هل السعر عادل؟": "Is the price fair?",
    "بحث AI": "AI Search",
    "محادثة طبيعية بالعربي": "Natural Arabic chat",
    "حاسبة التمويل": "Mortgage calculator",
    "حجز أوف بلان": "Off-plan booking",

    // ===== HOMEPAGE — Footer (organized) =====
    "نشرة عقار سكول الأسبوعية": "Aqar School weekly newsletter",
    "أحدث الوحدات + تحليلات السوق": "Latest units + market analytics",
    "في إيميل أسبوعي.": "in a weekly email.",
    "٤٠ ألف مشترك بيتلقّوا أهم الفرص قبل ما تطلع للناس. لو الإيميل ما عجبكش، تقدر تلغي بضغطة.":
      "40,000 subscribers get the top opportunities before they hit the public. Don't like the email? Unsubscribe in one click.",
    "اشتراك مجاناً": "Subscribe free",
    "تم الاشتراك ✓": "Subscribed ✓",
    "حمّل من": "Download on",
    "للمشترين": "For Buyers",
    "للبائعين": "For Sellers",
    "للسماسرة والمطورين": "For Brokers & Developers",
    "عن عقار سكول": "About Aqar School",
    "حساب ضمان بنكي": "Bank escrow",
    "معتمد من البنك المركزي": "Approved by Central Bank",
    "عقود بـ Blockchain": "Blockchain-secured contracts",
    "لا تزوير، لا تلاعب": "No forgery, no tampering",
    "تشفير AES-256": "AES-256 encryption",
    "حماية بنكية لبياناتك": "Bank-grade data protection",
    "سماسرة موثّقين": "Verified brokers",
    "٢,٤٠٠+ معتمد ومرخّص": "2,400+ certified & licensed",
    "القاهرة الجديدة، مصر": "New Cairo, Egypt",
    "دعم لايف ٢٤/٧": "24/7 live support",
    "طرق الدفع": "Payment methods",
    "© 2026 عقار سكول. جميع الحقوق محفوظة.": "© 2026 Aqar School. All rights reserved.",
    "سياسة الخصوصية": "Privacy Policy",
    "الشروط والأحكام": "Terms & Conditions",
    "الكوكيز": "Cookies",
    "خريطة الموقع": "Sitemap",
    "بحث AI Plus": "AI Search Plus",
    "احجز مقعدك": "Reserve seat",
    "ابدأ مجاناً": "Start free",
    "جاهز تنضم لعقار سكول؟": "Ready to join Aqar School?",
    "انضم لـ 12,000 عقار و2,400 سمسار في ثواني.":
      "Join 12,000 listings and 2,400 brokers in seconds.",
    "روابط سريعة": "Quick links",
    "تسجيل دخول": "Sign in",
    "أنشئ حساب جديد →": "Create new account →",
    "بروفايل سمسار": "Broker profile",
    "لوحة السمسار": "Broker dashboard",
    "لوحة المطوّر": "Developer dashboard",
    "أدوات AI": "AI tools",
    "💼 الوظائف": "💼 Jobs",
    "🏆 عقار أرينا": "🏆 Aqar Arena",
    "🎓 أكاديمية المبيعات": "🎓 Sales Academy",
    "أخبار السوق + AI": "Market news + AI",
    "أحدث المشاريع": "Newest projects",
    "💬 آخر تحديثات المجتمع": "💬 Latest community updates",
    "افتح المجتمع كامل ←": "Open full community ←",
    "اسأل، شارك، احذر، صوّت — 48,000 عضو": "Ask, share, warn, vote — 48,000 members",
    "شوف المزيد في المجتمع": "See more in the community",
    "⭐ وحدات مميزة": "⭐ Featured units",
    "شوف كل العقارات ←": "See all properties ←",
    "أحدث الوحدات المنتقاة من فريق عقار سكول":
      "The latest curated units from the Aqar School team",
    "الأدوات الذكية في ثواني": "Smart tools in seconds",
    "أذكى منصة عقارية في العالم العربي": "The smartest real-estate platform in the Arab world",
    "🪄 أذكى منصة عقارية في العالم العربي": "🪄 The smartest real-estate platform in the Arab world",

    // Generic units + common
    "عقار متاح": "Listings",
    "صفقة ناجحة": "Closed deals",
    "مطوّر شريك": "Partner developers",
    "سمسار معتمد": "Verified brokers",
    "أهلاً بعودتك! جاري التوجيه إلى لوحة التحكم…": "Welcome back! Redirecting to dashboard…",
    "تم إنشاء حسابك بنجاح! جاري التوجيه…": "Account created! Redirecting…",
    "ج.م": "EGP",
    "غرف": "BR",
    "م²": "m²",

    // ===== Submit Hero =====
    "عقارك يستحق مشتري": "Your property deserves a buyer",
    "جاد ومستعد": "ready to commit",
    "،": ",",
    "،\n      مش مجرد": ",\n      not just another",
    "مش مجرد": "not just another",
    "إعلان": "lost listing",
    "ضايع.": ".",
    "مش مجرد إعلان ضايع.": "not just another lost listing.",
    "ضيف عقارك في 4 دقايق →": "List your property in 4 minutes →",
    "اعرض وحدتك على 52,000 مشتري موثّق في 4 دقايق فقط — مع تحليل AI للسعر العادل، جلسة تصوير احترافية، وجولة 360° مجاناً.":
      "List your unit to 52,000 verified buyers in just 4 minutes — with AI fair-price analysis, a free pro photo session, and 360° tour.",
    "اعرض وحدتك على": "List your unit to",
    "مشتري موثّق في 4 دقايق فقط — مع تحليل":
      "verified buyers in just 4 minutes — with",
    "للسعر العادل، جلسة تصوير احترافية، وجولة 360° مجاناً.":
      "fair-price analysis, a pro photo session, and 360° tour.",
    "مفيش وسيط · مفيش رسوم خفية · مفيش وقت ضايع.":
      "No middleman · No hidden fees · No wasted time.",
    // Live activity feed lines
    "أحمد م. ضيف وحدة في التجمع الخامس · منذ ٤٢ ثانية":
      "Ahmed M. listed a unit in 5th Settlement · 42 sec ago",
    "منى ر. ضيفت فيلا في الشيخ زايد · منذ ١ دقيقة":
      "Mona R. listed a villa in Sheikh Zayed · 1 min ago",
    "كريم إ. ضيف شقة في ميفيدا · منذ ٢ دقايق":
      "Karim I. listed an apartment in Mivida · 2 min ago",
    "سارة ف. ضيفت دوبلكس في زايد · منذ ٤ دقايق":
      "Sara F. listed a duplex in Zayed · 4 min ago",
    "يوسف ك. ضيف بنتهاوس في العاصمة · منذ ٥ دقايق":
      "Youssef K. listed a penthouse in Capital · 5 min ago",
    "هدى س. ضيفت شاليه في الساحل · منذ ٧ دقايق":
      "Hoda S. listed a chalet in Sahel · 7 min ago",
    "محمد ع. ضيف شقة في المعادي · منذ ٩ دقايق":
      "Mohamed A. listed an apartment in Maadi · 9 min ago",
    "طارق إ. ضيف فيلا في 6 أكتوبر · منذ ١٢ دقيقة":
      "Tarek I. listed a villa in 6 October · 12 min ago",
    "نسمة أ. ضيفت تاون هاوس في بالم هيلز · منذ ١٤ دقيقة":
      "Nesma A. listed a townhouse in Palm Hills · 14 min ago",
    "تحليل AI لسعرك العادل": "AI Fair Price Analysis",
    "في أقل من 30 ثانية": "Under 30 seconds",
    "جلسة تصوير احترافية": "Pro Photo Session",
    "+ جولة 360° مجاناً": "+ 360° Tour Free",
    "مشتريون موثّقون فقط": "Verified Buyers Only",
    "صفر متفرجين": "Zero browsers",
    "دعم متابعة 24/7": "24/7 Follow-up",
    "حتى إتمام الصفقة": "Until deal closes",
    "ضيف عقارك الآن": "List My Property Now",
    "احسب السعر العادل أولاً": "Get Fair Price First",
    "اتكلم مع مستشار VIP": "Talk to VIP Advisor",
    "100% مجاني للمالك": "100% Free for owners",
    "4.9/5 تقييم 12K+ مالك": "4.9/5 from 12K+ owners",
    "الأسرع في الوصول للمشتري": "Fastest reach to buyers",
    "بياناتك مشفّرة": "Encrypted data",
    // Mock card
    "شقتك بعد ساعة من النشر": "Your unit, 1 hour after listing",
    "هتبان كده على الموقع": "This is how it'll appear",
    "مميز": "Featured",
    "يشاهدون الآن": "viewing now",
    "AI: عادل": "AI: Fair",
    "صورة": "photos",
    "م²": "m²",
    "عادل": "Fair",
    // Float chips
    "مشاهدات اليوم الأول": "First-day views",
    "طلبات معاينة": "Viewing requests",
    "طلب": "requests",
    // Stats bar
    "وحدة بيعت معانا": "Units sold with us",
    "متوسط وقت البيع": "Average selling time",
    "أعلى من السوق": "Above market",
    "رضا الملاك": "Owner satisfaction",
    "وحدة بيعت": "units sold",
    "أيام": "days",
    // Urgency
    "🎁 عرض حصري لأول 50 مالك هذا الأسبوع":
      "🎁 Exclusive offer for first 50 owners this week",
    "جلسة تصوير احترافية + جولة 360° + Boost إعلاني مجاني (قيمتها 4,500 ج.م) —":
      "Pro photo session + 360° tour + ad Boost (worth 4,500 EGP) —",
    "مجاناً تماماً": "Totally Free",
    "⏰ متبقي": "⏰ Remaining",
    "مكان فقط": "spots only",
    // 3 Pillars
    "أسرع بيع · أعلى سعر": "Faster Sale · Higher Price",
    "متوسط البيع 4 أيام بدل 60 يوم في باقي المنصات. بأسعار أعلى 18% بفضل مزاد المشترين.":
      "Average sale: 4 days vs 60 on other platforms. 18% higher prices via buyer auction.",
    "أسرع 15 مرة": "15× faster",
    "مشترين جادين فقط": "Serious Buyers Only",
    "كل مشتري عندنا متحقّق هويته ومعلوماته البنكية. مفيش متفرجين أو مكالمات ضايعة.":
      "Every buyer is identity & bank verified. No browsers or wasted calls.",
    "100% موثّقين": "100% verified",
    "دعم كامل حتى التوقيع": "Full Support Until Signing",
    "مستشارك الشخصي معاك من أول التصوير لحد التعاقد. بنتفاوض، بنوثّق، وبنحميك من النصب.":
      "Your dedicated advisor from photoshoot to contract. We negotiate, document, and protect you from fraud.",
    "فريق متخصص": "Specialized team",
    // Smart Tools dropdown
    "🪄 بحث AI": "🪄 AI Search",
    "هل السعر عادل؟": "Is Price Fair?",
    "البورصة العقارية": "Real Estate Stocks",
    "توب 10": "Top 10",
    "جدار المجتمع": "Community Wall",
    "إدارة العقار": "Property Mgmt",
    "بروفايل سمسار": "Broker Profile",
    "🚀 إطلاقات المشاريع": "🚀 Project Launches",
    "💼 صفقات VIP": "💼 VIP Deals",
    "🏆 عقار أرينا": "🏆 Aqar Arena",
    "💼 الوظائف": "💼 Jobs",
    "الأدوات الذكية": "Smart Tools",
    "حجز أوف بلان": "Off-plan Booking",
    "أوف بلان": "Off-plan",
    "وحدات تسليم فوري": "Ready Units",
    "تسليم فوري": "Ready Delivery",
    "حاسبة التمويل": "Mortgage Calculator",
    "التمويل": "Mortgage",
    "السماسرة": "Brokers",
    "السماسرة والتسويق": "Brokers & Agencies",
    "البودكاست": "Podcast",
    "التوب 10": "Top 10",
    "البورصة": "Stocks",
    "المجتمع": "Community",
    "ضيف عقارك الآن": "List Your Property Now",
    "احسب السعر العادل أولاً": "Estimate Fair Price First",
    "اتكلم مع مستشار VIP": "Talk to VIP Advisor",
    "100% مجاني للمالك": "100% Free for Owners",
    "4.9/5 تقييم 12K+ مالك": "4.9/5 from 12K+ owners",
    "الأسرع في الوصول للمشتري": "Fastest reach to buyers",
    "بياناتك مشفّرة": "Your data is encrypted",
    "شقتك بعد ساعة من النشر": "Your unit, 1 hour after listing",
    "هتبان كده على الموقع": "This is how it'll appear",
    "مشاهدات اليوم الأول": "First-day views",
    "طلبات معاينة": "Viewing requests",
    "وحدة بيعت معانا": "Units sold with us",
    "متوسط وقت البيع": "Average selling time",
    "أعلى من السوق": "Above market price",
    "رضا الملاك": "Owner satisfaction",
    "🎁 عرض حصري لأول 50 مالك هذا الأسبوع":
      "🎁 Exclusive offer for first 50 owners this week",
    "أيام": "days",
    "متبقي": "Remaining",
    "مكان فقط": "spots only",
    "أسرع بيع · أعلى سعر": "Faster Sale · Higher Price",
    "متوسط البيع 4 أيام بدل 60 يوم في باقي المنصات. بأسعار أعلى 18% بفضل مزاد المشترين.":
      "Average sale: 4 days vs 60 on other platforms. 18% higher prices via buyer auction.",
    "أسرع 15 مرة": "15× faster",
    "مشترين جادين فقط": "Serious Buyers Only",
    "كل مشتري عندنا متحقّق هويته ومعلوماته البنكية. مفيش متفرجين أو مكالمات ضايعة.":
      "Every buyer is identity & bank verified. No browsers or wasted calls.",
    "100% موثّقين": "100% verified",
    "دعم كامل حتى التوقيع": "Full Support Until Signing",
    "مستشارك الشخصي معاك من أول التصوير لحد التعاقد. بنتفاوض، بنوثّق، وبنحميك من النصب.":
      "Your dedicated advisor from photoshoot to contract. We negotiate, document, and protect you from fraud.",
    "فريق متخصص": "Specialized team",
    "PRESS & MEDIA KIT · 2026": "PRESS & MEDIA KIT · 2026",
    "منصة الوظائف العقارية الأولى": "The #1 Real Estate Jobs Platform",

    // ===== Submit Form Steps =====
    "إضافة عقارك خطوة بخطوة": "Add your property step by step",
    "اكتمل": "complete",
    "النوع": "Type",
    "التفاصيل": "Details",
    "الموقع": "Location",
    "الصور": "Photos",
    "السعر": "Price",
    "النشر": "Publish",
    "إيه اللي عايز": "What do you want to do",
    "تعمله بعقارك؟": "with your property?",
    "اختار اللي يناسبك في 3 خطوات سريعة — وهنفصّل لك الأدوات والخدمات على مقاسك.":
      "Pick what suits you in 3 quick steps — and we'll tailor the tools to you.",
    "اختار هدفك من العقار": "Choose your goal",
    "مطلوب": "Required",
    "مختار": "Selected",
    "أبيع وحدتي": "Sell my unit",
    "أعرضها على آلاف المشتريين الجادّين بأعلى سعر ممكن":
      "Show to thousands of serious buyers at the best price",
    "أأجّر وحدتي": "Rent my unit",
    "إيجار شهري أو سنوي مع متابعة كاملة وضمان الدفع":
      "Monthly or yearly rent with full support and payment guarantee",
    "استشارة استثمار": "Investment consultation",
    "مستشار خبير يحلّل وحدتك ويقترح أفضل قرار":
      "An expert analyzes your unit and suggests the best decision",
    "اختار نوع العقار": "Choose property type",
    "11 نوع متاح": "11 types available",
    "شقة": "Apartment", "فيلا": "Villa", "دوبلكس": "Duplex",
    "بنتهاوس": "Penthouse", "تاون هاوس": "Townhouse",
    "تواين هاوس": "Twin House", "ستوديو": "Studio",
    "شاليه": "Chalet", "أرض": "Land", "محل تجاري": "Shop",
    "إداري": "Office", "مخزن": "Warehouse",
    "حالة الوحدة الحالية": "Current unit condition",
    "يساعدنا في التسعير الدقيق": "Helps us price accurately",
    "⚡ تسليم فوري": "⚡ Ready Delivery",
    "جاهزة للسكن أو الاستلام": "Ready to move in",
    "🔨 قيد الإنشاء": "🔨 Under Construction",
    "أوف بلان · تسليم لاحق": "Off-plan · Future delivery",
    "💎 سوبر لوكس": "💎 Super Lux",
    "تشطيب فاخر بالكامل": "Fully luxurious finish",
    "✨ لوكس": "✨ Lux",
    "تشطيب راقي وعالي الجودة": "High-quality finish",
    "🛠 نصف تشطيب": "🛠 Semi-finished",
    "يحتاج لمسات نهائية": "Needs final touches",
    "🧱 على المحارة": "🧱 Core & shell",
    "بدون تشطيبات": "No finishing",
    "✓ ملخّص اختياراتك": "✓ Your selections",
    "هتعرض": "You're listing",
    "تمام، خلينا نكمل التفاصيل!": "Great, let's continue!",
    "السابق": "Previous",
    "التالي · تفاصيل الوحدة": "Next · Unit Details",
    "التالي · الموقع": "Next · Location",
    "التالي · الصور": "Next · Photos",
    "التالي · السعر والوصف": "Next · Price & Description",
    "التالي · النشر والترقية": "Next · Publish & Boost",
    "تفاصيل الوحدة": "Unit Details",
    "الذكية": "Smart",
    "الذكاء الاصطناعي هيقترح العنوان والسعر العادل بناءً على التفاصيل دي.":
      "AI will suggest the title and fair price based on these details.",
    "عنوان الإعلان": "Listing Title",
    "العنوان يجذب +40% مشاهدات": "Title drives +40% more views",
    "AI يكتبه": "Let AI write it",
    "المساحة": "Area",
    "المساحة الكلية": "Total area",
    "عدد الغرف والحمامات": "Rooms & Bathrooms",
    "غرف النوم": "Bedrooms",
    "الحمامات": "Bathrooms",
    "الدور والإطلالة": "Floor & View",
    "الدور": "Floor",
    "الإطلالة": "View",
    "المرافق والمميزات": "Amenities & Features",
    "اختار اللي متوفر": "Pick what's available",
    "حمام سباحة": "Pool", "جيم": "Gym", "حديقة": "Garden",
    "جراج": "Garage", "أمن 24/7": "24/7 Security",
    "مفروش": "Furnished", "تكييف": "AC", "شرفة": "Balcony",
    "أسانسير": "Elevator", "حيوانات": "Pets", "طاقة شمسية": "Solar",
    "سمارت هوم": "Smart Home",
    "AI تقدير السعر العادل": "AI Fair Price Estimate",
    "دقة": "Accuracy",
    "النطاق العادل:": "Fair range:",
    "مبني على 284 معاملة مشابهة": "Based on 284 similar transactions",
    "+18% فرصة بيع أعلى من السوق": "+18% higher selling chance vs market",
    "موقع دقيق بيزود فرصة البيع بـ 60% — اختار المدينة وحدد على الخريطة.":
      "Accurate location boosts sales by 60% — pick city and mark on the map.",
    "المدينة": "City",
    "الكمبوند / المشروع": "Compound / Project",
    "يساعدنا في التسعير الأدق": "For more accurate pricing",
    "اسم الكمبوند": "Compound name",
    "رقم البلوك / الشارع": "Block / Street #",
    "حدد الموقع على الخريطة": "Mark location on map",
    "دقة الموقع تزيد المصداقية": "Accurate location boosts trust",
    "مدرسة دولية": "International School",
    "مول": "Mall", "مستشفى": "Hospital",
    "المحور الرئيسي": "Main Axis",
    "صور الوحدة": "Unit Photos",
    "كل ما رفعت صور أكتر، كل ما زادت فرصة البيع — والذكاء الاصطناعي هيحسّن جودتها تلقائياً.":
      "More photos = higher chance to sell. AI auto-enhances quality.",
    "اسحب الصور هنا أو اضغط للاختيار": "Drag photos here or click to upload",
    "حد أدنى": "min",
    "صور": "photos",
    "حد أقصى 25 صورة · 10 ميجا للصورة": "Max 25 photos · 10MB each",
    "🛋 صالة": "🛋 Living Room", "🛏 غرفة نوم": "🛏 Bedroom",
    "🚿 حمام": "🚿 Bathroom", "🍳 مطبخ": "🍳 Kitchen",
    "🏡 الواجهة": "🏡 Façade",
    "جودة AI:": "AI Quality:",
    "🎁 جولة 360° + فيديو سينمائي مجاناً":
      "🎁 360° Tour + Cinematic Video FREE",
    "مصور محترف يزورك في خلال 48 ساعة — يصور ويعدّل ويرفع كل حاجة (قيمتها 4,500 ج.م)":
      "A pro photographer visits in 48 hours — shoots, edits, uploads everything (worth 4,500 EGP)",
    "اطلب الخدمة": "Request Service",
    "مستندات الملكية": "Title documents",
    "اختياري · بياناتك مشفّرة 256-bit": "Optional · 256-bit encrypted",
    "ارفع عقد الملكية أو الإنشاء": "Upload title or construction deed",
    "PDF فقط · مشفّر بتقنية البلوكتشين": "PDF only · Blockchain-secured",
    "والوصف الذكي": "& Smart Description",
    "اختار استراتيجية البيع وخلي الذكاء الاصطناعي يكتب وصف احترافي.":
      "Pick a strategy and let AI craft a pro description.",
    "استراتيجية التسعير": "Pricing Strategy",
    "كل استراتيجية ليها وقت بيع مختلف": "Each strategy has different selling time",
    "بيع سريع": "Quick Sale",
    "سعر أقل 5% من السوق": "5% below market",
    "السعر العادل": "Fair Price",
    "الأكثر شعبية": "Most popular",
    "أعلى ربح": "Highest Return",
    "سعر أعلى 10% من السوق": "10% above market",
    "السعر المطلوب": "Asking Price",
    "العادل:": "Fair:",
    "السعر الكلي (ج.م)": "Total Price (EGP)",
    "قابلية التفاوض": "Negotiability",
    "سعر ثابت — لا تفاوض": "Fixed — No negotiation",
    "تفاوض محدود — حتى 3%": "Limited — up to 3%",
    "متوسط — حتى 5%": "Moderate — up to 5%",
    "مرن — حتى 10%": "Flexible — up to 10%",
    "الوصف": "Description",
    "الذكاء الاصطناعي هيكتبه لك": "AI will write it for you",
    "اكتب وصف جذاب أو خلي AI يكتبه لك...":
      "Write a compelling description, or let AI do it...",
    "✨ AI يكتبه": "✨ Let AI write it",
    "المرحلة": "Final",
    "الأخيرة 🚀": "Step 🚀",
    "اختر باقة الترقية اللي تناسبك (اختياري) — وافّق على الشروط، وابدأ البيع!":
      "Pick a boost package (optional) — accept terms and start selling!",
    "باقة الترقية": "Boost Package",
    "اختياري · تزيد المشاهدات +5x": "Optional · +5× views",
    "إعلان مجاني": "Free Listing",
    "يظهر في النتائج العادية": "Appears in regular results",
    "مجاني": "Free",
    "ظهور لمدة 30 يوم": "30-day visibility",
    "10 صور": "10 photos",
    "دعم عبر الشات": "Chat support",
    "🔥 الأكثر اختياراً": "🔥 Most Popular",
    "في أعلى النتائج + شارة ذهبية": "Top of results + gold badge",
    "ج.م/أسبوع": "EGP/week",
    "أعلى صفحة البحث": "Top of search page",
    "25 صورة + جولة 360°": "25 photos + 360° tour",
    "شارة ذهبية مميزة": "Premium gold badge",
    "+5x مشاهدات مضمونة": "+5× guaranteed views",
    "مستشار شخصي": "Personal advisor",
    "إعلان مميز + Boost سوشيال": "Featured + social boost",
    "كل مزايا Premium": "All Premium benefits",
    "إعلان ممول على فيسبوك وإنستا": "Sponsored ads on Facebook & Instagram",
    "ظهور في النشرة الأسبوعية": "Featured in weekly newsletter",
    "مصور احترافي يجي للموقع": "Pro photographer on-site",
    "خط أمامي لـ 12K+ مشتري VIP": "Priority access to 12K+ VIP buyers",
    "🤖 توصية AI:": "🤖 AI Recommendation:",
    "أفضل وقت للنشر": "Best publishing time:",
    "الخميس الساعة 8 مساءً": "Thursday at 8 PM",
    "متوسط +42% مشاهدات في أول 24 ساعة. هل تنشر":
      "Avg +42% views in first 24h. Publish",
    "الآن": "now",
    "أم": "or",
    "تجدول": "schedule",
    "النشر؟": "for later?",
    "انشر الآن": "Publish now",
    "يبدأ الظهور فوراً": "Starts showing immediately",
    "جدول للوقت الأمثل": "Schedule for optimal time",
    "الخميس 8 مساءً (+42%)": "Thursday 8 PM (+42%)",
    "أؤكد أن كل البيانات المدخلة صحيحة وأن الوحدة مملوكة لي أو مُفوّض بالإعلان عنها.":
      "I confirm all data is correct and the unit is owned by me or I'm authorized to list it.",
    "أوافق على": "I agree to the",
    "شروط الاستخدام": "Terms of Service",
    "سياسة الخصوصية": "Privacy Policy",
    "🎉 انشر الإعلان الآن": "🎉 Publish Listing Now",
    "🔍 Live Preview": "🔍 Live Preview",
    "يتحدّث Live": "Live update",
    "شقة جديدة في انتظار التفاصيل": "New apartment awaiting details",
    "📍 اختار المدينة والكمبوند": "📍 Pick city & compound",
    "عادل": "Fair",
    "مساعد AI": "AI Assistant",
    "💡 نصيحة الخطوة:": "💡 Step Tip:",
    "اختار المعلومات بدقة — الذكاء الاصطناعي هيستخدمها لتقدير السعر العادل وكتابة وصف احترافي.":
      "Choose details carefully — AI uses them for fair price and pro description.",
    "📊 احصائيات حية": "📊 Live Stats",
    "مالك ضيفوا اليوم": "Owners listed today",
    "مشاهدات متوقعة (أسبوع)": "Expected views (week)",
    "متوسط الطلبات": "Avg requests",
    "سرعة البيع المتوقعة": "Expected selling speed",
    "30 يوم": "30 days",
    "عقارك اتنشر بنجاح!": "Your property is live!",
    "هتلاقي إعلانك مباشرة على صفحة العقارات، والمشتريين بدأوا يشوفوه.":
      "Your listing is live on the listings page, buyers are already viewing it.",
    "هنبعتلك إيميل + SMS بأرقام التواصل وتقرير الأداء أول 24 ساعة.":
      "You'll get email + SMS with contact details and a 24h performance report.",
    "رقم الإعلان": "Listing ID",
    "مشاهدة متوقعة": "Expected views",
    "طلب معاينة": "Viewing requests",
    "متوسط البيع": "Avg sale",
    "افتح لوحة التحكم": "Open Dashboard",
    "إغلاق": "Close",

    // ===== Price Check =====
    "هل سعر العقار ده": "Is this property price",
    "عادل؟": "fair?",
    "أدخل تفاصيل أي وحدة وخلّي الذكاء الاصطناعي يحلّل السعر مقارنة بـ":
      "Enter any unit details and let AI analyze the price against",
    "معاملة حقيقية": "real transactions",
    "ويوريك تاريخ السعر ومستقبله المتوقع.": "and reveal price history and forecast.",
    "بيانات العقار": "Property Details",
    "9 معايير · يستغرق التحليل أقل من 3 ثواني": "9 criteria · analysis in under 3s",
    "سكني": "Residential", "تجاري": "Commercial", "إداري ": "Administrative",
    "المنطقة": "Area",
    "الكمبوند": "Compound",
    "نوع الوحدة": "Unit Type",
    "المساحة (م²)": "Area (m²)",
    "عدد الغرف": "Bedrooms",
    "حالة التشطيب": "Finish",
    "نصف تشطيب": "Semi-finished",
    "تشطيب كامل": "Fully finished",
    "سوبر لوكس": "Super Lux",
    "مفروش بالكامل": "Fully furnished",
    "لاند سكيب + بحيرة": "Landscape + Lake",
    "شارع رئيسي": "Main Street",
    "بانوراما": "Panorama",
    "بحر": "Sea",
    "مفتوحة": "Open",
    "سنة التسليم": "Delivery Year",
    "2026 (تسليم فوري)": "2026 (Ready)",
    "جنيه مصري · EGP": "Egyptian Pound · EGP",
    "منخفض": "Low", "متوسط": "Medium", "مرتفع": "High",
    "بياناتك مشفّرة ومحمية": "Your data is encrypted",
    "نتيجة في أقل من 3 ثواني": "Result in under 3 seconds",
    "مجاناً تماماً": "Totally free",
    "حلّل السعر الآن": "Analyze Now",
    "نتيجة التحليل": "Analysis Result",
    "السعر العادل المقدّر:": "Estimated fair price:",
    "FAIRNESS SCORE / 100": "FAIRNESS SCORE / 100",
    "عادل تقريباً": "Roughly fair",
    "★ TOP MATCH": "★ TOP MATCH",
    "السعر مقبول مع ملاحظات بسيطة قابلة للتفاوض":
      "Acceptable price with minor negotiable points",
    "السعر المطلوب": "Asking Price",
    "السعر العادل": "Fair Price",
    "المرجع": "Reference",
    "مليون": "M",
    "الموقع ممتاز": "Excellent location",
    "المطور موثوق": "Trusted developer",
    "إطلالة مميزة": "Premium view",
    "السعر/م² أعلى من المتوسط": "Price/m² above avg",
    "دور بدون أسانسير فاخر": "Floor without premium elevator",
    "السعر/م² المطلوب": "Asked price/m²",
    "ج.م": "EGP",
    "▲ +6% عن المتوسط": "▲ +6% vs avg",
    "متوسط السعر/م²": "Avg price/m²",
    "آخر 90 يوم": "Last 90 days",
    "النطاق العادل": "Fair range",
    "ثقة 92%": "92% confidence",
    "معاملات مشابهة": "Similar transactions",
    "آخر 12 شهر": "Last 12 months",
    "تاريخ": "Price",
    "الأسعار": "History",
    "كيف تطور سعر المتر في ميفيدا من 2021 إلى 2026":
      "How m² price evolved in Mivida from 2021 to 2026",
    "نمو سنوي مركّب 24.2% — أعلى من متوسط القاهرة الجديدة بنسبة 4.8%":
      "CAGR 24.2% — 4.8% above New Cairo avg",
    "2021 (الأساس)": "2021 (baseline)",
    "2026 (الحالي)": "2026 (current)",
    "إجمالي النمو": "Total growth",
    "CAGR السنوي": "Annual CAGR",
    "وحدات": "Similar units",
    "مشابهة": "sold",
    "بيعت قريباً": "recently",
    "وحدات مماثلة بيعت في نفس الكمبوند خلال آخر 90 يوم":
      "Similar units sold in same compound in last 90 days",
    "⭐ أقرب مطابقة": "⭐ Closest match",
    "غرف": "rooms",
    "الدور 3": "Floor 3", "الدور 2": "Floor 2", "الدور 4": "Floor 4",
    "الدور 1": "Floor 1", "أرضي + حديقة": "Ground + Garden",
    "لاند سكيب": "Landscape",
    "يناير 2026": "January 2026",
    "فبراير 2026": "February 2026",
    "مارس 2026": "March 2026",
    "ديسمبر 2025": "December 2025",
    "المتوسط الموزون لكل المعاملات": "Weighted average of all transactions",
    "يستخدم خوارزمية التوزيع حسب المساحة والدور والإطلالة":
      "Uses area, floor, and view distribution algorithm",
    "تحليل عميق من الذكاء الاصطناعي": "Deep AI Analysis",
    "✓ تحليل إيجابي من الذكاء الاصطناعي": "✓ Positive AI Analysis",
    "⚠ تحليل تحذيري من الذكاء الاصطناعي": "⚠ Cautionary AI Analysis",
    "★ التوصية النهائية": "★ Final Recommendation",
    "اسأل الـ AI عن هذه الوحدة": "Ask AI about this unit",
    "تفاوض عبر مستشار معتمد": "Negotiate via certified advisor",
    "إزاي بنحلّل": "How we",
    "السعر؟": "analyze prices?",
    "خوارزمية متعددة العوامل + 18 متغير + بيانات حقيقية مُحدّثة أسبوعياً":
      "Multi-factor algorithm + 18 variables + weekly-updated real data",
    "قاعدة بيانات حية": "Live Database",
    "12,000+ معاملة حقيقية تُحدّث أسبوعياً من الشهر العقاري والوسطاء المعتمدين والمطوّرين الكبار في مصر.":
      "12,000+ real transactions updated weekly from registry, brokers, and major developers.",
    "خوارزمية XGBoost": "XGBoost Algorithm",
    "نموذج تنبؤي بدقة 92% يُقدّر السعر العادل بناءً على 18 متغير مع أوزان ديناميكية تتحدث مع كل صفقة جديدة.":
      "92%-accurate predictive model on 18 variables with dynamic weights.",
    "تحليل الموقع الدقيق": "Precise Location Analysis",
    "يقيس المسافة من المدارس، المستشفيات، المولات، والمحاور الرئيسية، ويحسب درجة الراحة الحضرية.":
      "Measures distances to schools, hospitals, malls, axes — computes urban comfort score.",
    "مؤشرات الاقتصاد الكلي": "Macro Economic Indicators",
    "يأخذ في الحسبان التضخم، سعر الصرف، أسعار الفائدة، ومعدلات البيع لتقدير السعر المستقبلي بدقة.":
      "Factors in inflation, FX, interest rates, and sale velocity for accurate forecast.",
    "تنبيهات السعر الذكية": "Smart Price Alerts",
    "لما يتغير السعر العادل للمنطقة بـ ±5% يوصلك إشعار فوري على الموبايل والإيميل مع التحليل المبدئي.":
      "When fair price moves ±5%, you get instant SMS + email alerts with analysis.",
    "تقرير PDF تفاوضي": "Negotiation PDF Report",
    "حمّل تقرير تحليلي من 8 صفحات بأرقام السوق والمقارنات والتوصيات تستخدمه فعلياً في التفاوض على السعر.":
      "Download 8-page analytical report with market data, comparisons, and recommendations.",

    // ===== Broker Arena =====
    "BETA • موسم إبريل 2026": "BETA · April 2026 Season",
    "🏆 عقار أرينا": "🏆 Aqar Arena",
    "مسابقة أسبوعية للسماسرة — تحديات يومية، لوحة صدارة حية، ومكافآت حقيقية. اكسب XP، ارفع مستواك، وكن البروكر رقم 1 في مصر.":
      "Weekly broker contest — daily quests, live leaderboard, real rewards. Earn XP, level up, be #1.",

    // ===== Launches =====
    "LIVE NOW — احجز وحدتك من الموبايل": "LIVE NOW — book from your phone",
    "🚀 لونش اليوم: كمبوند \"ذا كابيتال\" — العاصمة الإدارية":
      "🚀 Today's Launch: \"The Capital\" — New Capital",
    "320 وحدة — أسعار ما قبل اللونش — خصم 15% حصري لأول 50 حاجز":
      "320 units — pre-launch prices — 15% off for first 50 reservations",
    "يوم": "day",
    "ساعة": "hour",
    "دقيقة": "min",
    "ثانية": "sec",
    "جميع اللونشات": "All Launches",

    // ===== Business Deals =====
    "صفقات حصرية — Verified Investors Only":
      "Exclusive deals — Verified Investors Only",
    "أراضي ومشاريع كبرى لرجال الأعمال":
      "Lands & Mega-Projects for Business Leaders",
    "قاعدة بيانات مختارة من أكبر الصفقات العقارية في مصر — أراضي استثمارية، مشاريع قيد التنفيذ، وفرص حصرية لا تُعرض علناً.":
      "Curated database of Egypt's biggest real-estate deals — investment lands, in-progress projects, and exclusive non-public opportunities.",
    "صفقة نشطة": "Active deals",
    "إجمالي القيمة (ج.م)": "Total value (EGP)",
    "مستثمر موثّق": "Verified investors",
    "محافظة": "governorates",

    // ===== MORTGAGE PAGE =====
    "AI-POWERED · LIVE BANK RATES · APRIL 2026":
      "AI-POWERED · LIVE BANK RATES · APRIL 2026",
    "أذكى طريقة تختار": "The smartest way to choose",
    "تمويلك العقاري": "your mortgage",
    "احسب قسطك الشهري في 5 ثواني، قارن":
      "Calculate your monthly payment in 5 seconds, compare",
    "بنك مصري": "Egyptian banks",
    "بأسعار محدثة Live، وخلّي الذكاء الاصطناعي يقترح لك أفضل عرض حسب راتبك ووضعك المالي.":
      "with live-updated rates, and let AI suggest the best offer for your salary and financial situation.",
    "بنك مصري": "Egyptian Banks",
    "سرعة الحساب": "Calc Speed",
    "دقة التطابق": "Match Accuracy",
    "أسعار محدثة": "Live Rates",

    // Calculator
    "احسب قسطك الذكي": "Calculate Your Smart Payment",
    "حرّك السلايدر وشوف النتيجة Live": "Drag the slider, see live result",
    "قيمة العقار": "Property Value",
    "المقدم": "Down Payment",
    "مدة السداد": "Loan Term",
    "الفائدة السنوية": "Annual Rate",
    "نصيحة AI:": "AI Tip:",
    "زود مقدمك 5% توفّر": "Increase down 5%, save",
    "من الفوائد الإجمالية.": "of total interest.",
    "زود مقدمك إلى 30% توفّر": "Increase down to 30%, save",
    "من الفوائد.": "in interest.",
    "مقدمك ممتاز! دلوقتي ركّز على إيجاد أقل فائدة في السوق.":
      "Your down payment is excellent! Now focus on finding the lowest rate.",
    "قلل المدة إلى 20 سنة توفّر": "Reduce term to 20 years, save",
    "فوائد إضافية.": "extra interest.",
    "المدة الحالية ممتازة — توازن مثالي بين القسط والفوائد.":
      "Current term is excellent — perfect balance between payment and interest.",
    "فيه بنوك بفائدة أقل من": "There are banks with rates below",
    "— قارن قبل ما تقرر.": "— compare before deciding.",
    "الفائدة الحالية تنافسية — أنت في الشريحة الذكية.":
      "Current rate is competitive — you're in the smart tier.",

    // Result Card
    "القسط الشهري": "Monthly Payment",
    "Monthly Payment": "Monthly Payment",
    "180 قسط": "180 payments",
    "شهرياً · على مدى 15 سنة": "monthly · over 15 years",
    "شهرياً · على مدى": "monthly · over",
    "سنة": "years",
    "أصل التمويل": "Principal",
    "إجمالي الفوائد": "Total Interest",
    "إجمالي المدفوعات": "Total Payments",
    "📊 تحليل الأمان المالي": "📊 Affordability Analysis",
    "راتبك الشهري": "Your Monthly Salary",
    "أدخل راتبك لعرض تحليل الأمان المالي": "Enter your salary to see affordability",
    "✓ ممتاز —": "✓ Excellent —",
    "⚠ مقبول —": "⚠ Acceptable —",
    "✗ مرتفع جداً —": "✗ Too high —",
    "القسط =": "Payment =",
    "من راتبك (الموصى به: أقل من 30%)": "of your salary (recommended: under 30%)",
    "من راتبك (يفضّل تقليل المدة أو زيادة المقدم)":
      "of your salary (prefer reducing term or increasing down payment)",
    "من راتبك (يفضّل البحث عن سعر أقل أو زيادة المقدم)":
      "of your salary (look for lower rate or increase down payment)",
    "قدّم على أفضل بنك": "Apply to Best Bank",

    // Best 3 Banks
    "🏆 SMART RANKING": "🏆 SMART RANKING",
    "أفضل 3 بنوك": "Top 3 Banks",
    "على مقاسك": "for you",
    "رتّبنا البنوك تلقائياً حسب أقساطك — هتدفع أقل، هتتقبل أسرع.":
      "We auto-ranked banks by your payment — pay less, get approved faster.",
    "🥇 الأفضل لك": "🥇 Best for you",
    "🥈 الثاني الأفضل": "🥈 Second Best",
    "🥉 ترتيب 3": "🥉 Rank 3",
    "فائدة": "Rate",
    "قدّم على هذا البنك": "Apply to this Bank",
    "💰 توفّر": "💰 Save",
    "ج.م مقارنة بأعلى عرض": "EGP vs highest offer",

    // What-If
    "💡 WHAT-IF": "💡 WHAT-IF",
    "إيه لو دفعت": "What if you paid",
    "دفعة إضافية؟": "extra?",
    "جرّب دفعة مقدمة إضافية وشوف هتوفّر كام من الفوائد على مدى التمويل.":
      "Try an extra prepayment and see how much interest you'd save.",
    "دفعة مبكرة (Pre-payment)": "Early Prepayment",
    "لو دفعت مبلغ إضافي بعد سنتين من بداية التمويل، هتقلّل الفوائد بشكل كبير. جرّب الأرقام:":
      "If you pay extra after 2 years, you'll cut interest significantly. Try the numbers:",
    "المبلغ الإضافي (ج.م)": "Extra Amount (EGP)",
    "💰 إجمالي توفير": "💰 Total Savings",
    "توفر": "Save",
    "شهر من سنين التمويل +": "months from term +",
    "من الفوائد!": "in interest!",

    // Eligibility
    "🤖 AI ELIGIBILITY CHECK": "🤖 AI ELIGIBILITY CHECK",
    "هل أنت": "Are you",
    "مؤهّل للتمويل؟": "eligible?",
    "جاوب 3 أسئلة سريعة وشوف عدد البنوك اللي هتقبلك فوراً.":
      "Answer 3 quick questions, see how many banks accept you instantly.",
    "تحقق فوري من الأهلية": "Instant Eligibility Check",
    "راتبك الشهري الصافي (ج.م)": "Net Monthly Salary (EGP)",
    "سنوات الخبرة الوظيفية": "Years of Experience",
    "أقل من سنتين": "Less than 2 years",
    "2-5 سنين": "2-5 years",
    "5-10 سنين": "5-10 years",
    "أكتر من 10 سنين": "More than 10 years",
    "السجل الائتماني": "Credit History",
    "ممتاز (مفيش ديون)": "Excellent (no debts)",
    "جيد": "Good",
    "مقبول": "Fair",
    "يحتاج تحسين": "Needs improvement",
    "أنت مؤهّل في": "You're eligible at",
    "من 15 بنك": "of 15 banks",
    "— نسبة قبولك المتوقعة": "— expected approval rate",
    "أعلى تمويل ممكن:": "Maximum loan possible:",

    // Banks Table
    "🏦 ALL BANKS · LIVE RATES": "🏦 ALL BANKS · LIVE RATES",
    "قارن بين": "Compare",
    "15 بنك": "15 banks",
    "في دقيقة": "in a minute",
    "الأسعار محدّثة إبريل 2026 — مرتّبة حسب الأنسب لك.":
      "Rates updated April 2026 — ranked by best fit for you.",
    "فلترة:": "Filter:",
    "أقل فائدة": "Lowest Rate",
    "مدة طويلة (30 سنة)": "Long Term (30 yrs)",
    "إسلامي": "Islamic",
    "دخل مرن": "Flexible Income",
    "تمويل عالي (90%+)": "High Finance (90%+)",
    "الترتيب": "Rank",
    "البنك": "Bank",
    "الفائدة": "Rate",
    "أقصى مدة": "Max Term",
    "التمويل": "Finance",
    "أقل دخل": "Min Income",
    "تقديم": "Apply",
    "قدّم": "Apply",
    "ضمان الدقة:": "Accuracy Guarantee:",
    "الأسعار محدّثة إبريل 2026 من المواقع الرسمية لكل بنك. يحق للبنك تحديد الفائدة النهائية بعد تقييم طلبك. جميع المعاملات تخضع لسياسة البنك المركزي المصري.":
      "Rates updated April 2026 from official bank websites. Final rate determined by bank after evaluation. All transactions subject to Central Bank of Egypt policy.",

    // Bank names (preserve transliterations)
    "بنك التعمير والإسكان": "Housing & Development Bank",
    "البنك الأهلي المصري": "National Bank of Egypt (NBE)",
    "فيصل الإسلامي (إسلامي)": "Faisal Islamic Bank (Islamic)",
    "بنك مصر": "Banque Misr",
    "البنك العربي الأفريقي": "Arab African Bank",
    "CIB — البنك التجاري الدولي": "CIB — Commercial International Bank",
    "بنك الإسكندرية": "Bank of Alexandria",
    "البنك الأهلي المتحد": "Ahli United Bank",
    "QNB الأهلي": "QNB Al Ahli",
    "بنك الإسكندرية ALEX": "Alex Bank ALEX",
    "أبوظبي التجاري": "Abu Dhabi Commercial",
    "بنك الاستثمار العربي": "Arab Investment Bank",
    "Crédit Agricole مصر": "Crédit Agricole Egypt",
    "Standard Chartered": "Standard Chartered",
    "HSBC مصر": "HSBC Egypt",

    // Golden Tips
    "💡 GOLDEN RULES": "💡 GOLDEN RULES",
    "5 قواعد": "Golden Rules",
    "لاختيار التمويل الذكي": "for smart mortgage selection",
    "نصائح من خبراء التمويل العقاري — توفر عليك مئات الآلاف في الفوائد.":
      "Tips from mortgage experts — save you hundreds of thousands in interest.",
    "قاعدة 30%": "The 30% Rule",
    "30% من دخلك الصافي": "30% of net income",
    "عشان تعيش مرتاح وتفضل تقدر تدفّر.":
      "to live comfortably and keep saving.",
    "مقدم أكبر = راحة أكتر": "Bigger Down Payment = More Peace",
    "5% زيادة في المقدم": "5% increase in down payment",
    "في إجمالي الفوائد على مدى التمويل.": "in total interest over the loan.",
    "قارن قبل ما تقرر": "Compare Before Deciding",
    "1% في الفائدة": "1% in interest",
    "على 25 سنة — قارن دايماً بين 3 بنوك على الأقل.":
      "over 25 years — always compare at least 3 banks.",
    "المدة الأقصر أوفر": "Shorter Term Saves More",
    "15 سنة": "15 years",
    "بدلاً من 25 يوفّر": "instead of 25 saves",
    "من الفوائد — بس القسط هيكون أعلى.":
      "of interest — but monthly payment will be higher.",
    "التأمين والرسوم": "Insurance & Fees",
    "تأمين الحياة": "life insurance",
    "ورسوم الإصدار — ممكن تضيف 1-2% على التكلفة الإجمالية.":
      "and origination fees — may add 1-2% to total cost.",
    "السداد المبكر": "Early Repayment",
    "السداد المبكر بدون غرامة": "early repayment without penalty",
    "— لو ظروفك اتحسنت تقدر تخلص بسرعة.":
      "— if your situation improves, you can finish faster.",

    // Common bank/finance terms
    "قسط": "payments",
    "أقساط": "payments",
    "مليون": "M",
    "ألف": "K",
    "ج.م": "EGP",

    // ===== FEATURES PAGE =====
    "World-Class Features": "World-Class Features",
    "ليه عقار سكول أقوى منصة عقارية في العالم؟":
      "Why Aqar School is the world's most powerful real-estate platform?",
    "جمعنا أفضل الممارسات العالمية من Zillow، Opendoor، Redfin، و Magnolia Realty، وضفنا عليها تقنيات AI وفهم عميق للسوق العربي":
      "We combined best global practices from Zillow, Opendoor, Redfin, and Magnolia Realty, with AI tech and deep Arab market understanding.",
    "🤖 Flagship Feature": "🤖 Flagship Feature",
    "AI Price Estimator — التقييم الذكي للأسعار":
      "AI Price Estimator — Intelligent Pricing",
    "أول نموذج ذكي مُدرّب على أكثر من 2 مليون صفقة عقارية في الشرق الأوسط لإعطائك السعر العادل في ثواني":
      "The first AI model trained on over 2M real estate deals across the Middle East to give you the fair price in seconds.",
    "جرّبه الآن مجاناً": "Try it Now Free",
    "المدينة والحي": "City & District",
    "القاهرة الجديدة — التجمع الخامس": "New Cairo — 5th Settlement",
    "الشيخ زايد — بيفرلي هيلز": "Sheikh Zayed — Beverly Hills",
    "6 أكتوبر — الحي الثامن": "6 October — 8th District",
    "العاصمة الإدارية": "New Capital",
    "المعادي": "Maadi",
    "الساحل الشمالي": "North Coast",
    "المساحة (م²)": "Area (m²)",
    "الغرف": "Rooms",
    "التشطيب": "Finish",
    "حالة العقار": "Property Age",
    "جديد (1-3 سنوات)": "New (1-3 years)",
    "مستعمل (3-10 سنوات)": "Used (3-10 years)",
    "قديم (+10 سنوات)": "Old (10+ years)",
    "حلّل الآن": "Analyze Now",
    "جاري التحليل...": "Analyzing...",
    "AI ESTIMATED FAIR VALUE": "AI ESTIMATED FAIR VALUE",
    "هامش دقة:": "Accuracy margin:",
    "أقل سعر في السوق": "Lowest market price",
    "متوسط السوق": "Market average",
    "أعلى سعر في السوق": "Highest market price",
    "نسبة الإستثمار ROI سنوي": "Annual investment ROI",

    // 15 Features section
    "🏆 أقوى 15 فيتشر": "🏆 Top 15 Features",
    "تكنولوجيا تحوّل تجربة شراء العقار":
      "Technology that transforms property buying",
    "مساعد AI محادثي 24/7": "24/7 Conversational AI Assistant",
    "دردشة ذكية بالعربية والإنجليزية تجاوب على كل أسئلتك، تقترح وحدات، وتحسب أقساطك.":
      "Smart Arabic+English chat that answers all your questions, suggests units, and calculates payments.",
    "Virtual Reality Tours": "Virtual Reality Tours",
    "جولات 360° بدقة 8K مع إمكانية قياس الأبعاد داخل الوحدة افتراضياً.":
      "360° tours in 8K resolution with virtual dimension measurement inside the unit.",
    "Market Heatmap": "Market Heatmap",
    "خريطة حرارية تظهر أسعار المتر في كل منطقة وتوقعات الأسعار القادمة.":
      "Heatmap showing per-m² prices in every area and upcoming price forecasts.",
    "E-Signature + Blockchain": "E-Signature + Blockchain",
    "توقيع معتمد قانونياً مع Hash على Blockchain يمنع أي تلاعب بالعقد.":
      "Legally certified signature with blockchain hash that prevents any contract tampering.",
    "Escrow Payment Gateway": "Escrow Payment Gateway",
    "حساب ضمان بنكي يحمي أموالك حتى اكتمال كل مرحلة من مراحل البناء.":
      "Bank escrow account protecting your money until each construction stage is complete.",
    "Live Construction Cams": "Live Construction Cams",
    "كاميرات 4K مباشرة على موقع كل مشروع، Time-lapse أسبوعي.":
      "Live 4K cameras at every project site, weekly time-lapse video.",
    "Neighborhood Insights": "Neighborhood Insights",
    "بيانات عن المدارس، المستشفيات، المواصلات، ومعدل الأمان لكل حي.":
      "Data on schools, hospitals, transit, and safety scores for every district.",
    "Sustainability Score": "Sustainability Score",
    "تقييم استدامة المبنى: عزل حراري، طاقة شمسية، وكفاءة الطاقة.":
      "Building sustainability rating: thermal insulation, solar, and energy efficiency.",
    "3D Interior Designer": "3D Interior Designer",
    "صمم ديكور وحدتك، جرّب الألوان والأثاث قبل الاستلام، واحصل على عروض الموردين.":
      "Design your unit's decor, try colors and furniture before delivery, get vendor quotes.",
    "ROI Investment Calculator": "ROI Investment Calculator",
    "احسب عائد الاستثمار المتوقع، الإيجار الشهري، وفرص إعادة البيع.":
      "Calculate expected ROI, monthly rent, and resale opportunities.",
    "Developer Verification": "Developer Verification",
    "نتحقق من كل مطور: تراخيص، سجلات، مشاريع سابقة، ومصادر التمويل.":
      "We verify every developer: licenses, records, past projects, and funding sources.",
    "Legal Contract Review": "Legal Contract Review",
    "فريق قانوني متخصص يراجع كل عقد ويعلمك بأي بنود تحتاج تعديل.":
      "Specialized legal team reviews every contract and flags clauses needing changes.",
    "Community & Reviews": "Community & Reviews",
    "تقييمات حقيقية من السكان، ومجتمع أون لاين لكل كمبوند.":
      "Real reviews from residents, and an online community for every compound.",
    "Smart Alerts": "Smart Alerts",
    "إشعارات ذكية عند ظهور وحدة تطابق معاييرك أو انخفاض الأسعار.":
      "Smart notifications when units matching your criteria appear or prices drop.",
    "Multi-Currency Support": "Multi-Currency Support",
    "ادفع بالدولار، اليورو، الريال، أو الجنيه — والنظام يحسب سعر الصرف الحي.":
      "Pay in USD, EUR, SAR, or EGP — the system computes live FX rate.",

    // How it Works
    "🚀 إزاي بنشتغل": "🚀 How We Work",
    "رحلتك في 4 خطوات بس": "Your journey in just 4 steps",
    "ابحث واختار": "Search & Choose",
    "استخدم فلاتر متقدمة أو اترك AI يقترح عليك الوحدة المثالية":
      "Use advanced filters or let AI suggest your perfect unit",
    "عاين وتفاوض": "Visit & Negotiate",
    "جولة 360°، معاينة ميدانية، أو دردشة مع المطور مباشرة":
      "360° tour, on-site visit, or direct chat with developer",
    "وقّع وادفع": "Sign & Pay",
    "توقيع إلكتروني موثق + دفع آمن عبر بوابة محمية":
      "Authenticated e-signature + secure payment via protected gateway",
    "تابع واستلم": "Track & Receive",
    "تابع البناء Live، استلم الوحدة، وابدأ حياتك الجديدة":
      "Track construction live, receive your unit, and start your new life",

    // CTA
    "جاهز تبدأ؟": "Ready to start?",
    "سجّل مجاناً وجرّب كل المميزات لمدة 30 يوم بدون أي التزامات":
      "Sign up free and try all features for 30 days, no commitment.",
    "افتح حسابك المجاني": "Open Your Free Account",

    // Common labels =====
    "مع احترامي": "With respect",
    "ملحوظات": "Notes",
    "تواصل معنا": "Contact Us",
    "اتصل بنا": "Call Us",
    "احجز معاينة": "Book Viewing",
    "أرسل رسالة": "Send Message",
    "ابدأ الآن": "Get Started",
    "اعرف المزيد": "Learn More",
    "شاهد المزيد": "View More",
    "كل الحقوق محفوظة": "All rights reserved",
    "خدمة العملاء": "Customer Service",
    "العودة للرئيسية": "← Back to Home",
    "← العودة للرئيسية": "← Back to Home"
  };

  /* =======================================================
     CACHE & APPLY (TreeWalker — catches every text node)
     ======================================================= */
  const _origCache = new WeakMap();

  // Skip these containers entirely
  const SKIP_TAGS = new Set([
    'SCRIPT', 'STYLE', 'NOSCRIPT', 'CODE', 'PRE',
    'INPUT', 'TEXTAREA', 'SELECT'
  ]);

  function shouldSkipNode(node) {
    let p = node.parentElement;
    while (p) {
      if (SKIP_TAGS.has(p.tagName)) return true;
      if (p.hasAttribute('data-no-translate')) return true;
      if (p.hasAttribute('data-brand')) return true;
      // NOTE: previously we skipped data-i18n containers, but that meant elements
      // whose i18n key was missing from i18n.js never fell through to PHRASES.
      // Now we let the TreeWalker process them too — if i18n.js already
      // translated them, PHRASES won't have a match and they're left alone.
      p = p.parentElement;
    }
    return false;
  }

  function applyPhrases(lang) {
    // Walk every text node in body
    const walker = document.createTreeWalker(
      document.body,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
          if (shouldSkipNode(node)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);

    nodes.forEach(node => {
      if (!_origCache.has(node)) _origCache.set(node, node.nodeValue);
      const orig = _origCache.get(node);
      const trim = orig.trim();
      if (!trim) return;
      if (lang === "en") {
        if (PHRASES[trim]) {
          const lead = orig.match(/^\s*/)[0];
          const trail = orig.match(/\s*$/)[0];
          node.nodeValue = lead + PHRASES[trim] + trail;
        }
      } else {
        // Restore Arabic
        node.nodeValue = orig;
      }
    });

    // Placeholders
    document.querySelectorAll("input[placeholder], textarea[placeholder]").forEach(el => {
      if (el.hasAttribute("data-i18n-placeholder")) return;
      if (!el.dataset.origPh) el.dataset.origPh = el.placeholder || '';
      const op = el.dataset.origPh.trim();
      if (lang === "en" && PHRASES[op]) {
        el.placeholder = PHRASES[op];
      } else if (lang === "ar") {
        el.placeholder = el.dataset.origPh;
      }
    });

    // Aria-labels (e.g., on icon-only buttons)
    document.querySelectorAll("[aria-label]").forEach(el => {
      if (!el.dataset.origAria) el.dataset.origAria = el.getAttribute('aria-label') || '';
      const oa = el.dataset.origAria.trim();
      if (lang === "en" && PHRASES[oa]) {
        el.setAttribute('aria-label', PHRASES[oa]);
      } else if (lang === "ar") {
        el.setAttribute('aria-label', el.dataset.origAria);
      }
    });
  }

  /* =======================================================
     HOOK INTO LANG TOGGLE — observe html.dir
     ======================================================= */
  function getCurrentLang() {
    return document.documentElement.lang === "en" ||
           document.documentElement.dir === "ltr" ? "en" : "ar";
  }

  // Re-entrancy guard so applyPhrases mutations don't re-trigger the body observer infinitely
  let _applying = false;
  let _scheduled = null;

  function safeApply() {
    if (_applying) return;
    _applying = true;
    try { applyPhrases(getCurrentLang()); }
    finally {
      // Allow microtask queue to drain before clearing the flag,
      // so the body observer's coalesced batch (caused by our writes)
      // sees the guard and skips itself.
      setTimeout(() => { _applying = false; }, 0);
    }
  }

  function scheduleApply() {
    if (_applying) return;
    if (_scheduled) return;
    _scheduled = setTimeout(() => { _scheduled = null; safeApply(); }, 80);
  }

  function init() {
    safeApply();

    // 1. Observe html attribute changes (i18n.js sets dir/lang)
    new MutationObserver(() => safeApply()).observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["dir", "lang"]
    });

    // 2. Observe BODY for newly-rendered nodes (stories, videos, news cards
    //    rendered by JS via innerHTML need to be translated too).
    if (document.body) {
      new MutationObserver((muts) => {
        if (_applying) return;
        // Only re-apply if at least one mutation added actual element/text content.
        for (const m of muts) {
          if (m.type === "childList" && (m.addedNodes.length || m.removedNodes.length)) {
            scheduleApply();
            return;
          }
          if (m.type === "characterData") {
            scheduleApply();
            return;
          }
        }
      }).observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
      });
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  // Expose for manual triggering
  window.AqarPhraseI18n = { apply: applyPhrases, refresh: safeApply };
})();
